LOGIN    = "admin"
PASSWORD = "C1sco12345!"
URL      = "https://198.19.202.94"
